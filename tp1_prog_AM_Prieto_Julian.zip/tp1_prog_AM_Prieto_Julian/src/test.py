import math
import numpy as np
x = np.array([[1, 4],[4, 2], [7, 3], [1, 5]])
y = np.array([[1], [0], [1], [0]])
m, n = x.shape # <-- m = filas = 4, n = cols = 3
theta = np.zeros(n)

def sigmoide(theta): return 1/(1+np.exp(-theta @ x.T)) # @ es el producto matricial (np.dot)

def gradiente(theta):
    sumatoria = 0
    valores_sigmoide = sigmoide(theta)
    return np.array([[np.sum((y - valores_sigmoide) @ x),
                      np.sum((y - valores_sigmoide) * 1),]])
    # for i in range(m):
    #     sumatoria += (valores_sigmoide[i] - y[i])*x[i]
    #     # print(sumatoria, " <-- {} iteracion".format(i+1), end="\n\n")
    # return sumatoria
    
def hessiano(theta):
    sumatoria = 0
    valores_sigmoide = sigmoide(theta)
    d1 = np.sum((valores_sigmoide * (1-valores_sigmoide)) @ x @ x.T)
    d2 = np.sum((valores_sigmoide * (1-valores_sigmoide)) @ x)
    d3 = np.sum((valores_sigmoide * (1-valores_sigmoide)) * 1)
    return np.array([[d1, d2],[d2, d3]])
    # for i in range(m):
    #   sumatoria += -valores_sigmoide[i]*(1-valores_sigmoide[i])*x[i]*x[i].T
    # return sumatoria

def newton(theta):
    grad = gradiente(theta)
    hess = hessiano(theta)
    hess_inv = np.linalg.inv(hess)
    det = hess_inv @ grad.T # @ es el producto matricial (np.dot)
    print(det, det.shape, " <-- det")
    det_1 = det[0][0]
    det_2 = det[1][0]
    # det_3 = det[2][0]

    theta[0] = det_1
    theta[1] = det_2
    # theta[2] = det_3
    return theta



print(x, x.shape, " <-- x")
print("----------------")
print(x.T, x.T.shape, " <-- x.T")
print("----------------")
print(y, y.shape, " <-- y")
print("----------------")
print(theta, theta.shape, " <-- theta")
print("----------------")
pred = sigmoide(theta)
print(pred, pred.shape, " <-- pred")
print("----------------")
grad = gradiente(theta)
print(grad, grad.shape, " <-- grad")
print("----------------")
hess = hessiano(theta)
print(hess, hess.shape, " <-- hess")
print("----------------")
new_theta = newton(theta)
print(new_theta, new_theta.shape, " <-- new_theta")
print("----------------")
